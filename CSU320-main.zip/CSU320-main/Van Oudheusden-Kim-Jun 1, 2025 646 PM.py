
import random

print("Welcome to the HigherLower Guessing Game!")

##Prompt for Lower and Upper Bounds
while True:
    try:
        lower_bound = int(input("Enter your lower bound here: "))
        upper_bound = int(input("Enter your upper bound here: "))
        
        if lower_bound < upper_bound:
            
            break
        
        else: lower_bound > upper_bound
        print("Error: Lower bound has to be less than upper bound!")
            
        
    except ValueError:
        print("Error:Only enter valid integers.")

##Random Number Generator

target = random.randint(lower_bound, upper_bound)

##Game Loop Prompt and Decision Branching
while True:
    try:
        user_guess = int(input(f"Guess a number between {lower_bound} and {upper_bound}: "))
        
        if user_guess < lower_bound or user_guess > upper_bound:
            print(f"Error: Stay within your bounds!")
            continue
    
        if user_guess < target:
            print("Nope, too low.")
    
        elif user_guess > target:
            print("Nope, too high.")
    
        else:
            print("You got it!")
            break
    except ValueError:
        print("Error: Only enter valid integers!")
    
    

##Exit loop and end program
print("You Win! Thanks for Playing!")

